################################
##Generated with a lot of love##
##    with   EasyPython       ##
##Web site: easycoding.tn     ##
################################
import RPi.GPIO as GPIO
import time
import serial
import pygame

import adafruit_fingerprint
from http.server import BaseHTTPRequestHandler, HTTPServer

uart = serial.Serial("/dev/ttyUSB0", baudrate=57600, timeout=1)
finger = adafruit_fingerprint.Adafruit_Fingerprint(uart)
GPIO.setmode(GPIO.BCM)
servoPIN = 17
GPIO.setmode(GPIO.BCM)
GPIO.setup(servoPIN, GPIO.OUT)
GPIO.setup(22, GPIO.OUT, initial=GPIO.LOW)
p = GPIO.PWM(servoPIN, 50) # GPIO 17 for PWM with 50Hz

Request = None
def get_fingerprint():
    """Get a finger print image, template it, and see if it matches!"""
    print("Waiting for image...")
    while finger.get_image() != adafruit_fingerprint.OK:
        pass
    print("Templating...")
    if finger.image_2_tz(1) != adafruit_fingerprint.OK:
        return False
    print("Searching...")
    if finger.finger_search() != adafruit_fingerprint.OK:
        return False
    return True

def get_fingerprint():
    """Get a finger print image, template it, and see if it matches!"""
    print("Waiting for image...")
    while finger.get_image() != adafruit_fingerprint.OK:
        pass
    print("Templating...")
    if finger.image_2_tz(1) != adafruit_fingerprint.OK:
        return False
    print("Searching...")
    if finger.finger_search() != adafruit_fingerprint.OK:
        return False
    return True
  
class RequestHandler_httpd(BaseHTTPRequestHandler):
  def do_GET(self):
    global Request
    messagetosend = bytes('Hello World',"utf")
    self.send_response(200)
    self.send_header('Content-Type', 'text/plain')
    self.send_header('Content-Length', len(messagetosend))
    self.end_headers()
    self.wfile.write(messagetosend)
    Request = self.requestline
    Request = Request[5 : int(len(Request)-9)]
    print(Request)
    
    if Request == '098765':
      p.start(2.5) # Initialization
      p.ChangeDutyCycle(10)
      time.sleep(2.5)
      p.ChangeDutyCycle(2.5)
      time.sleep(0.5)
    if Request == '1':
      GPIO.output(22, GPIO.HIGH)
    if Request == '0':
      GPIO.output(22, GPIO.LOW)
    if Request == '12345':
      get_fingerprint()
      if finger.finger_id == 10:
        pygame.init()
        my_sound = pygame.mixer.Sound('/home/manis15/Downloads/absen.wav')
        my_sound.play()
      else:
        print("tidak ada data")
      

      
    return

      

server_address_httpd = ('192.168.1.4',8080)
httpd = HTTPServer(server_address_httpd, RequestHandler_httpd)
print('Starting Server :')
httpd.serve_forever()
GPIO.cleanup()
