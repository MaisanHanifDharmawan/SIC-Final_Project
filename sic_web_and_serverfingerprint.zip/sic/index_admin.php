<?php
@session_start();
include "koneksi.php";

if (!@$_SESSION['admin']) {

  include "login.php";

} else { ?>
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SIC-Admin</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <!-- https://fonts.google.com/specimen/Roboto -->
    <link rel="stylesheet" href="css/fontawesome.min.css">
    <!-- https://fontawesome.com/ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- https://getbootstrap.com/ -->
    <link rel="stylesheet" href="css/templatemo-style.css">
    <link rel="shortcut icon" href="img/logo.jpeg" >
   
  </head>

  <body id="reportsPage">
    <?php
    $sql_terlogin = mysqli_query($db, "SELECT * FROM admin WHERE id_admin= '$_SESSION[admin]'") or die($db->error);

    $data_terlogin = mysqli_fetch_array($sql_terlogin);


    ?>
    <div class="" id="home">
      <nav class="navbar navbar-expand-xl">
        <div class="container h-100">
          <a class="navbar-brand" href="index_admin.php">
          <img src="img/logo.jpeg" alt="" style="margin-top: 5px;" width="100px" height="70px">
          </a>
          <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse"
            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Toggle navigation">
            <i class="fas fa-bars tm-nav-icon"></i>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto h-100">
              <li class="nav-item">
                <a class="nav-link active" href="index_admin.php">
                  <i class="fas fa-tachometer-alt"></i>
                  Dashboard
                  <span class="sr-only">(current)</span>
                </a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="meeting_admin.php">
                  <i class="far fa-file-alt"></i>
                  Jadwal Meeting
                </a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="accounts_admin.php">
                  <i class="far fa-user"></i>
                  Accounts
                </a>
              </li>

            </ul>
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link d-block" href="logout.php?sesi=admin">
                  <b>Logout</b>
                </a>
              </li>
            </ul>
          </div>
        </div>

      </nav>
      <div class="container">
        <div class="row">
          <div class="col">
            <p class="text-white mt-5 mb-5">Welcome back, <b>Admin</b></p>
          </div>
        </div>
        <!-- row -->
        <div class="row tm-content-row">
          <div class="tm-block-col tm-col-avatar">
            <div class="tm-bg-primary-dark tm-block tm-block-avatar">
              <h2 class="tm-block-title">Profil</h2>
              <div class="tm-avatar-container">
                <img src="img/avatar.png" alt="Avatar" class="tm-avatar img-fluid mb-4" />
              </div>

            </div>
          </div>
          <div class="tm-block-col tm-col-account-settings">
            <div class="tm-bg-primary-dark tm-block tm-block-settings">
              <h2 class="tm-block-title">Pengaturan Akun</h2>
              <form action="" class="tm-signup-form row">
                <div class="form-group col-lg-6">
                  <label for="name">Nama</label>
                  <input readonly id="nama" name="nama" value="<?php echo $data_terlogin['Nama'] ?>" type="text"
                    style="background-color:#669999;" class="form-control validate" />
                </div>
                <div class="form-group col-lg-6">
                  <label for="email">Email</label>
                  <input readonly id="email" name="email" type="email" style="background-color:#669999;"
                    value="<?php echo $data_terlogin['Email'] ?>" class="form-control validate" />
                </div>

                <div class="form-group col-lg-6">
                  <label for="jabatan">Jabatan</label>
                  <input readonly id="jabatan" name="jabatan" type="text" value="<?php echo $data_terlogin['Jabatan'] ?>"
                    class="form-control validate" style="background-color:#669999;" />
                </div>
                <div class="form-group col-lg-6">
                  <label for="lampu_on">Kode Lampu ON</label>
                  <input readonly id="lampu_on" name="lampu_on" type="text" value="1"
                    class="form-control validate" style="background-color:#669999;" />
                </div>
                <div class="form-group col-lg-6">
                  <label for="lampu_off">Kode Lampu OFF</label>
                  <input readonly id="lampu_off" name="lampu_off" type="text" value="0"
                    class="form-control validate" style="background-color:#669999;" />
                </div>
                






            </div>
          </div>
        </div>
      </div>
      <footer class="tm-footer row tm-mt-small">
        <div class="col-12 font-weight-light">
          <p class="text-center text-white mb-0 px-4 small">
            Copyright &copy; <b>2023</b> SIC MAN 15.
            
            
          </p>
        </div>
      </footer>

      <script src="js/jquery-3.3.1.min.js"></script>
      <!-- https://jquery.com/download/ -->
      <script src="js/moment.min.js"></script>
      <!-- https://momentjs.com/ -->
      <script src="js/Chart.min.js"></script>
      <!-- http://www.chartjs.org/docs/latest/ -->
      <script src="js/bootstrap.min.js"></script>
      <!-- https://getbootstrap.com/ -->
      <script src="js/tooplate-scripts.js"></script>
      <script>
        Chart.defaults.global.defaultFontColor = 'white';
        let ctxLine,
          ctxBar,
          ctxPie,
          optionsLine,
          optionsBar,
          optionsPie,
          configLine,
          configBar,
          configPie,
          lineChart;
        barChart, pieChart;
        // DOM is ready
        $(function () {
          drawLineChart(); // Line Chart
          drawBarChart(); // Bar Chart
          drawPieChart(); // Pie Chart

          $(window).resize(function () {
            updateLineChart();
            updateBarChart();
          });
        })
      </script>
  </body>

  </html>

  <?php
}
?>