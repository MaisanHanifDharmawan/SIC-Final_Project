<?php
include "koneksi.php";

if(isset($_POST['upload'])){
    
	$ruangan = $_POST['ruangan'];
	$jam = $_POST['jam'];
	$tanggal = $_POST['tanggal'];
	$password = $_POST['pw_meeting'];


    $sql = "INSERT INTO meeting (ruangan, jam, tanggal, password_meeting ) VALUES ('$ruangan', '$jam', '$tanggal', '$password')";
if (mysqli_query($db, $sql)) {
    echo '<script>alert("Upload Jadwal Meeting Berhasil")</script>';
     echo "<script>window.location='meeting_admin.php';</script>";
} else {
    echo '<script>alert("Upload Gagal")</script>';
    echo "<script>window.location='meeting_admin.php';</script>";
}
    
	
	
				
}
?>