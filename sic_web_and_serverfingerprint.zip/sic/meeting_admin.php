<?php
@session_start();
include "koneksi.php";

if(!@$_SESSION['admin']) {
    
        include "login.php";
    
} else { ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>SIC-Meeting</title>
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Roboto:400,700"
    />
    <!-- https://fonts.google.com/specimen/Roboto -->
    <link rel="stylesheet" href="css/fontawesome.min.css" />
    <!-- https://fontawesome.com/ -->
    <link rel="stylesheet" href="jquery-ui-datepicker/jquery-ui.min.css" type="text/css" />
    <!-- http://api.jqueryui.com/datepicker/ -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- https://getbootstrap.com/ -->
    <link rel="stylesheet" href="css/templatemo-style.css">
    <link rel="shortcut icon" href="img/logo.jpeg" >
 
  </head>

  <body>
  <?php
         $sql_terlogin = mysqli_query($db, "SELECT * FROM meeting ORDER BY id_meeting") or die ($db->error);
         
         $data_terlogin = mysqli_fetch_array($sql_terlogin);
         
       
      ?>
    <nav class="navbar navbar-expand-xl">
      <div class="container h-100">
        <a class="navbar-brand" href="index_admin.php">
        <img src="img/logo.jpeg" alt="" style="margin-top: 5px;" width="100px" height="70px">
        </a>
        <button
          class="navbar-toggler ml-auto mr-0"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <i class="fas fa-bars tm-nav-icon"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mx-auto h-100">
            <li class="nav-item">
              <a class="nav-link" href="index_admin.php">
                <i class="fas fa-tachometer-alt"></i> Dashboard
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
                            <a class="nav-link" href="meeting_admin.php">
                                <i class="far fa-file-alt"></i>
                                Jadwal Meeting
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="accounts_admin.php">
                                <i class="far fa-user"></i>
                                Accounts
                            </a>
                        </li>
                        
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link d-block" href="login.php">
                                <b>Logout</b>
                            </a>
                        </li>
                    </ul>
        </div>
      </div>
    </nav>
    <div class="col-12 tm-block-col">
            <div class="tm-bg-primary-dark tm-block tm-block-settings">
              <h2 class="tm-block-title">Buat Jadwal Meeting</h2>

              
              <form action="upload_jadwal.php" method="post" class="tm-signup-form row">
                <div class="form-group col-lg-6">
                  <label for="name">Ruangan</label>
                  <input
                    id="ruangan"
                    name="ruangan"
                    type="text"
                    class="form-control validate"
                  />
                </div>
                <div class="form-group col-lg-6">
                  <label for="email">Jam</label>
                  <input
                    id="jam"
                    name="jam"
                    type="time"
                    class="form-control validate"
                  />
                </div>
                <div class="form-group col-lg-6">
                  <label for="jabatan">Tanggal</label>
                  <input
                    id="tanggal"
                    name="tanggal"
                    type="date"
                    class="form-control validate"
                  />
                </div>
                <div class="form-group col-lg-6">
                  <label for="pw_meeting">Password Meeting</label>
                  <input
                    id="pw_meeting"
                    name="pw_meeting"
                    type="text"
                    class="form-control validate"
                  />
                </div>
              
                
                <div class="form-group col-lg-6">
                <input
                      type="submit"
                      name="upload"
                      value="Upload Jadwal Meeting"
                      class="btn btn-primary btn-block text-uppercase"
                    />
                </div>
                
              </form>
            </div>
          </div>


          <div class="col-12 tm-block-col">
              <div class="tm-bg-primary-dark tm-block tm-block-taller tm-block-scroll">
                  <h2 class="tm-block-title">Jadwal Meeting</h2>
                  <table class="table">
                      <thead>
                          <tr>
                              <th scope="col">NO.</th>
                              <th scope="col">Ruangan</th>
                              <th scope="col">Jam</th>
                              <th scope="col">Tanggal</th>
                              <th scope="col">Password Meeting</th>
                              <th scope="col">Aksi</th>
                              
                          </tr>
                      </thead>
                      <tbody>
                          
                            <?php
                          $no = 1;	
                            while($data_meeting= mysqli_fetch_assoc($sql_terlogin)){	
                           ?>
                           <tr>
                              <td><?php echo $no?></td>
                              <td><?php echo $data_meeting['ruangan'] ?></td>
                              <td><?php echo $data_meeting['jam'] ?></td>
                              <td><?php echo $data_meeting['tanggal'] ?></td>
                              <td><?php echo $data_meeting['password_meeting'] ?></td>
                              
                              <td>
                              <form role="form" action="hapus.php" method="post">
                                <input type="hidden" name="id" value='<?php echo $data_meeting['id_meeting'] ?>'>
                                <input type="submit" name="hapus" value="HAPUS">
                                </form>
                              </td>
                             
                              
                              
                          </tr>
                          <?php 
                        $no++;
                        } ?>
                        
                      </tbody>
                  </table>
              </div>
              <footer class="tm-footer row tm-mt-small">
        <div class="col-12 font-weight-light">
          <p class="text-center text-white mb-0 px-4 small">
            Copyright &copy; <b>2023</b> SIC MAN 15.
            
            
          </p>
        </div>
      </footer>

    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- https://jquery.com/download/ -->
    <script src="jquery-ui-datepicker/jquery-ui.min.js"></script>
    <!-- https://jqueryui.com/download/ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- https://getbootstrap.com/ -->
    <script>
      $(function() {
        $("#expire_date").datepicker({
          defaultDate: "10/22/2020"
        });
      });
    </script>
  </body>
</html>

<?php
}
?>