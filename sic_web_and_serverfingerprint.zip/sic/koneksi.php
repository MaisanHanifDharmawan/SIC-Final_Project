<?php
$db = mysqli_connect("localhost", "root", "", "sic_project");

//---fungsi2---//
function cek_session($isi_admin, $isi_pengajar) {
    if(@$_SESSION['admin']) {
        echo $isi_admin;
    } else if(@$_SESSION['pengajar']) {
        echo $isi_pengajar;
    }
}
?>