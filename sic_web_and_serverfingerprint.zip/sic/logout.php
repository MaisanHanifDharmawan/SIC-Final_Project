<?php
@session_start();

if(@$_GET['sesi'] == 'admin') {
	unset($_SESSION['admin']);
	echo "<script>window.location='login.php';</script>";
} else if(@$_GET['sesi'] == 'karyawan') {
	unset($_SESSION['karyawan']);
	echo "<script>window.location='login.php';</script>";
} 


?>