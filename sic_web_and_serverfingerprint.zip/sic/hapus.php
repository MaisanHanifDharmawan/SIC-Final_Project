<?php
include "koneksi.php";

if(isset($_POST['hapus'])){
    $id = $_POST['id'];


    $sql = "DELETE FROM meeting WHERE id_meeting = $id";
if (mysqli_query($db, $sql)) {
    echo '<script>alert("Berhasil Menghapus Jadwal Meeting")</script>';
     echo "<script>window.location='meeting_admin.php';</script>";
} else {
    echo '<script>alert("Gagal Menghapus Jadwal Meeting")</script>';
    echo "<script>window.location='meeting_admin.php';</script>";
}
    
	
	
				
}
?>